def getMETARForAirport(airport_id: str) -> str:
    return str()

def getWeatherAtLocation(latitude: float, longitude: float, altitude_m: float):
    pass
