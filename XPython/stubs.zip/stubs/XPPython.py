VERSION = 'x.x.x'
PLUGINSPATH = 'Resources/plugins/PythonPlugins'
INTERNALPLUGINSPATH = 'Resources/plugsin/XPPython3'


def XPPythonGetDicts():
    return {}


def XPPythonGetCapsules():
    return {}
